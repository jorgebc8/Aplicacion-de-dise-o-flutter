package com.example.restaurant_design

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
